/*
 * Copyright (c) 2018-2019 REV Robotics
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of REV Robotics nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "rev/CANSparkMax.h"

#include "rev/CANSparkMaxDriver.h"

#include <hal/CAN.h>
#include <hal/CANAPI.h>

using namespace rev;

constexpr CANSparkMax::ExternalFollower CANSparkMax::kFollowerDisabled;
constexpr CANSparkMax::ExternalFollower CANSparkMax::kFollowerSparkMax;
constexpr CANSparkMax::ExternalFollower CANSparkMax::kFollowerPhoenix;

CANSparkMax::CANSparkMax(int deviceID, MotorType type)
    : CANSparkMaxLowLevel(deviceID, type) {
}

void CANSparkMax::Set(double speed) {
    // Only for 'get' api
    m_setpoint = speed;
    SetpointCommand(speed, ControlType::kDutyCycle);
}

void CANSparkMax::SetVoltage(units::volt_t output) {
    // simple conversion too keep Get() trivial
    // Use GetAppliedOutput() instead of Get() for
    // actual applied duty cycle
    double dOutput = units::unit_cast<double>(output);
    m_setpoint = dOutput / 12.0;
    SetpointCommand(dOutput, ControlType::kVoltage);
}

double CANSparkMax::Get() const { return m_setpoint; }

void CANSparkMax::SetInverted(bool isInverted) { 
    c_SparkMax_SetInverted(static_cast<c_SparkMax_handle>(m_sparkMax), isInverted);
}

bool CANSparkMax::GetInverted() const { 
    uint8_t inverted;
    c_SparkMax_GetInverted(static_cast<c_SparkMax_handle>(m_sparkMax), &inverted);
    return inverted ? true : false; 
}

void CANSparkMax::Disable() { Set(0); }

void CANSparkMax::StopMotor() { Set(0); }

void CANSparkMax::PIDWrite(double output) { Set(output); }

CANEncoder CANSparkMax::GetEncoder(CANEncoder::EncoderType sensorType, int counts_per_rev) { 
    // if (m_encoder == NULL) {
    //     m_encoder = new CANEncoder{*this, sensorType, counts_per_rev};
    // }

    // return m_encoder;

    return CANEncoder{*this, sensorType, counts_per_rev};;
}

CANEncoder CANSparkMax::GetAlternateEncoder(CANEncoder::AlternateEncoderType sensorType, int counts_per_rev) {
    // if (m_altEncoder == NULL) {
    //     m_altEncoder = new CANEncoder{*this, sensorType, counts_per_rev};
    // }

    // return *m_altEncoder;
    
    return CANEncoder{*this, sensorType, counts_per_rev};
}

CANAnalog CANSparkMax::GetAnalog(CANAnalog::AnalogMode mode) { 
    // if (m_analog == NULL) {
    //     m_analog = new CANAnalog{*this, mode};
    // }

    // return *m_analog;
    return CANAnalog{*this, mode}; 
}

CANPIDController CANSparkMax::GetPIDController() { 
    // if (m_pidController == NULL) {
    //     m_pidController = new CANPIDController{*this};
    // } 

    // return *m_pidController; 

    return CANPIDController{*this};
}

CANDigitalInput CANSparkMax::GetForwardLimitSwitch(
    CANDigitalInput::LimitSwitchPolarity polarity) {
    // if (m_fwSwitch == NULL) {
    //     m_fwSwitch = new CANDigitalInput{*this, CANDigitalInput::LimitSwitch::kForward,
    //                                         polarity};
    // }

    // return *m_fwSwitch;
    return CANDigitalInput{*this, CANDigitalInput::LimitSwitch::kForward,
                           polarity};
}

CANDigitalInput CANSparkMax::GetReverseLimitSwitch(
    CANDigitalInput::LimitSwitchPolarity polarity) {
    // if (m_revSwitch == NULL) {
    //     m_revSwitch = new CANDigitalInput{*this, CANDigitalInput::LimitSwitch::kReverse,
    //                                         polarity};
    // }

    // return *m_revSwitch;
    return CANDigitalInput{*this, CANDigitalInput::LimitSwitch::kReverse,
                           polarity};
}

CANError CANSparkMax::SetSmartCurrentLimit(unsigned int limit) {
    return SetSmartCurrentLimit(limit, 0, 20000);
}

CANError CANSparkMax::SetSmartCurrentLimit(unsigned int stallLimit,
                                           unsigned int freeLimit,
                                           unsigned int limitRPM) {
    auto status = c_SparkMax_SetSmartCurrentLimit(static_cast<c_SparkMax_handle>(m_sparkMax), stallLimit, freeLimit, limitRPM);
    return static_cast<CANError>(status);
}

CANError CANSparkMax::SetSecondaryCurrentLimit(double limit, int chopCycles) {
    auto status = c_SparkMax_SetSecondaryCurrentLimit(static_cast<c_SparkMax_handle>(m_sparkMax), limit, chopCycles);
    return static_cast<CANError>(status);
}

CANError CANSparkMax::SetIdleMode(IdleMode idleMode) {
    auto status = c_SparkMax_SetIdleMode(static_cast<c_SparkMax_handle>(m_sparkMax), static_cast<c_SparkMax_IdleMode>(idleMode));
    return static_cast<CANError>(status);
}

CANSparkMax::IdleMode CANSparkMax::GetIdleMode() {
    c_SparkMax_IdleMode idleMode;
    c_SparkMax_GetIdleMode(static_cast<c_SparkMax_handle>(m_sparkMax), &idleMode);
    return static_cast<CANSparkMax::IdleMode>(idleMode);
}

CANError CANSparkMax::EnableVoltageCompensation(double nominalVoltage) {
    auto status = c_SparkMax_EnableVoltageCompensation(static_cast<c_SparkMax_handle>(m_sparkMax), nominalVoltage);
    return static_cast<CANError>(status);
}

CANError CANSparkMax::DisableVoltageCompensation() {
    auto status = c_SparkMax_DisableVoltageCompensation(static_cast<c_SparkMax_handle>(m_sparkMax));
    return static_cast<CANError>(status);
}

double CANSparkMax::GetVoltageCompensationNominalVoltage() {
    float nominalVoltage;
    c_SparkMax_GetVoltageCompensationNominalVoltage(static_cast<c_SparkMax_handle>(m_sparkMax), &nominalVoltage);
    return static_cast<double>(nominalVoltage);
}

CANError CANSparkMax::SetOpenLoopRampRate(double rate) {
    auto status = c_SparkMax_SetOpenLoopRampRate(static_cast<c_SparkMax_handle>(m_sparkMax), rate);
    return static_cast<CANError>(status);
}

CANError CANSparkMax::SetClosedLoopRampRate(double rate) {
    auto status = c_SparkMax_SetClosedLoopRampRate(static_cast<c_SparkMax_handle>(m_sparkMax), rate);
    return static_cast<CANError>(status);
}

double CANSparkMax::GetOpenLoopRampRate() {
    float rate;
    c_SparkMax_GetOpenLoopRampRate(static_cast<c_SparkMax_handle>(m_sparkMax), &rate);
    return static_cast<double>(rate);
}

double CANSparkMax::GetClosedLoopRampRate() {
    float rate;
    c_SparkMax_GetClosedLoopRampRate(static_cast<c_SparkMax_handle>(m_sparkMax), &rate);
    return static_cast<double>(rate);
}

CANError CANSparkMax::Follow(const CANSparkMax& leader, bool invert) {
    return Follow(kFollowerSparkMax, leader.GetDeviceId(), invert);
}

CANError CANSparkMax::Follow(ExternalFollower leader, int deviceID,
                             bool invert) {
    FollowConfig maxFollower;
    maxFollower.leaderArbId = (!leader.arbId ? 0 : leader.arbId | deviceID);
    maxFollower.config.predefined = leader.configId;
    maxFollower.config.invert = invert;
    return SetFollow(maxFollower);
}

bool CANSparkMax::IsFollower() { 
    uint8_t isFollower;
    c_SparkMax_IsFollower(static_cast<c_SparkMax_handle>(m_sparkMax), &isFollower); 
    return isFollower ? true : false;
}

uint16_t CANSparkMax::GetFaults() { 
    uint16_t faults;
    c_SparkMax_GetFaults(static_cast<c_SparkMax_handle>(m_sparkMax), &faults);
    return faults;
}

uint16_t CANSparkMax::GetStickyFaults() {
    uint16_t faults;
    c_SparkMax_GetStickyFaults(static_cast<c_SparkMax_handle>(m_sparkMax), &faults);
    return faults;
}

bool CANSparkMax::GetFault(FaultID faultID) {
    uint8_t fault;
    c_SparkMax_GetFault(static_cast<c_SparkMax_handle>(m_sparkMax), static_cast<c_SparkMax_FaultID>(faultID), &fault);
    return fault ? true : false;
}

bool CANSparkMax::GetStickyFault(FaultID faultID) {
    uint8_t fault;
    c_SparkMax_GetStickyFault(static_cast<c_SparkMax_handle>(m_sparkMax), static_cast<c_SparkMax_FaultID>(faultID), &fault);
    return fault ? true : false;
}

double CANSparkMax::GetBusVoltage() {
    float tmp;
    c_SparkMax_GetBusVoltage(static_cast<c_SparkMax_handle>(m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

double CANSparkMax::GetAppliedOutput() {
    float tmp;
    c_SparkMax_GetAppliedOutput(static_cast<c_SparkMax_handle>(m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

double CANSparkMax::GetOutputCurrent() {
    float tmp;
    c_SparkMax_GetOutputCurrent(static_cast<c_SparkMax_handle>(m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

double CANSparkMax::GetMotorTemperature() {
    float tmp;
    c_SparkMax_GetMotorTemperature(static_cast<c_SparkMax_handle>(m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

CANError CANSparkMax::ClearFaults() {
    auto status = c_SparkMax_ClearFaults(static_cast<c_SparkMax_handle>(m_sparkMax));
    return static_cast<CANError>(status);
}

CANError CANSparkMax::BurnFlash() {
    auto status = c_SparkMax_BurnFlash(static_cast<c_SparkMax_handle>(m_sparkMax));
    return static_cast<CANError>(status);
}

CANError CANSparkMax::SetCANTimeout(int milliseconds) {
    auto status = c_SparkMax_SetCANTimeout(static_cast<c_SparkMax_handle>(m_sparkMax), milliseconds);
    return static_cast<CANError>(status);
}

CANError CANSparkMax::EnableSoftLimit(SoftLimitDirection direction, bool enable) {
    c_SparkMax_LimitDirection dir;

    if (direction == SoftLimitDirection::kForward) {
        dir = c_SparkMax_kForward;
    } else {
        dir = c_SparkMax_kReverse;
    }
    auto status = c_SparkMax_EnableSoftLimit(static_cast<c_SparkMax_handle>(m_sparkMax), dir, enable ? 1 : 0);
    return static_cast<CANError>(status);
}

CANError CANSparkMax::SetSoftLimit(CANSparkMax::SoftLimitDirection direction, double limit) {
    c_SparkMax_LimitDirection dir;

    if (direction == SoftLimitDirection::kForward) {
        dir = c_SparkMax_kForward;
    } else {
        dir = c_SparkMax_kReverse;
    }
    auto status = c_SparkMax_SetSoftLimit(static_cast<c_SparkMax_handle>(m_sparkMax), dir, limit);
    return static_cast<CANError>(status);
}

double CANSparkMax::GetSoftLimit(CANSparkMax::SoftLimitDirection direction) {
    c_SparkMax_LimitDirection dir;
    float limit;

    if (direction == SoftLimitDirection::kForward) {
        dir = c_SparkMax_kForward;
    } else {
        dir = c_SparkMax_kReverse;
    }

    c_SparkMax_GetSoftLimit(static_cast<c_SparkMax_handle>(m_sparkMax), dir, &limit);
    return static_cast<double>(limit);
}

bool CANSparkMax::IsSoftLimitEnabled(CANSparkMax::SoftLimitDirection direction) {
    c_SparkMax_LimitDirection dir;

    if (direction == SoftLimitDirection::kForward) {
        dir = c_SparkMax_kForward;
    } else {
        dir = c_SparkMax_kReverse;
    }

    uint8_t enable;
    c_SparkMax_IsSoftLimitEnabled(static_cast<c_SparkMax_handle>(m_sparkMax), dir, &enable);
    return enable ? true : false;
}

int CANSparkMax::GetFeedbackDeviceID() {
    uint32_t id;
    c_SparkMax_GetFeedbackDeviceID(static_cast<c_SparkMax_handle>(m_sparkMax), &id);
    return static_cast<int>(id);
}

CANError CANSparkMax::GetLastError() {
    return static_cast<CANError>(c_SparkMax_GetLastError(static_cast<c_SparkMax_handle>(m_sparkMax)));
}
