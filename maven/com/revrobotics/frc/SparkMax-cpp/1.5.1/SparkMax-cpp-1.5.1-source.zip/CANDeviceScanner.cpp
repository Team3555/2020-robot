/*
 * Copyright (c) 2018-2019 REV Robotics
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of REV Robotics nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "rev/CANDeviceScanner.h"
#include "rev/CANSparkMaxFrames.h"
#include "rev/CANSparkMaxDriver.h"

#include <stdlib.h>
#include <stdint.h>

#include <hal/CAN.h>
#include <hal/HALBase.h>
#include <chrono>
#include <thread>

using namespace rev;

CANBusScanner::CANBusScanner(int bufferSize)
    : m_streamBufferSize(bufferSize),
      m_streamHandle(0) { }

CANBusScanner::~CANBusScanner() {
    Stop();
}

bool CANBusScanner::Start() {
    int32_t status = 0;
    HAL_CAN_OpenStreamSession(&m_streamHandle, 0, 0, m_streamBufferSize, &status);
    if (status != 0) {
        if (m_streamHandle != 0) {
            HAL_CAN_CloseStreamSession(m_streamHandle);
        }
        return false;
    }
    return true;
}

void CANBusScanner::Stop() {
    if (m_streamHandle != 0) {
        HAL_CAN_CloseStreamSession(m_streamHandle);
    }
    m_streamHandle = 0;
}

std::vector<CANScanIdentifier> CANBusScanner::CANBusScan() {
    std::map<CANScanIdentifier, bool> devices;
    uint32_t read = 0;
    int32_t status = 0;

    HAL_CANStreamMessage messages[100];

    if (m_streamHandle == 0) {
        // there was an error opening the stream, re-try, on failure return nothing
        if (!Start()) {
            return std::vector<CANScanIdentifier>();
        }
    }

    static const int numArray = 20;
    uint32_t idArray[numArray];
    size_t numUnique = 0;
    c_SparkMax_IDQuery(idArray, numArray, &numUnique);
    
    int counter = 0;

    bool zeroSeen = false;

    HAL_CAN_ReadStreamSession(m_streamHandle, messages, m_streamBufferSize, &read, &status);

    // read failed, move on until next call
    if (status != 0) {
        Stop();
        return std::vector<CANScanIdentifier>();
    }

    for (uint8_t j = 0; j < read; j++) {
        bool passedFilter = false;
        auto frame = messages[j].messageID;
        CANScanIdentifier id = {static_cast<frc_deviceType_t>(((frame & 0x1F000000) >> 24)),
                                static_cast<frc_manufacturer_t>(((frame & 0x00FF0000) >> 16)),
                                static_cast<uint16_t>(frame & 0x3F), 
                                0};
        if (m_lookUpMap.find(frame >> 16) != m_lookUpMap.end()) {
            // manufacturer ID is in lookup table, there should be valid IDs in m_registeredDevices
            std::string name = m_lookUpMap.at(frame >> 16);
            std::vector<uint32_t> validIds = m_registeredDevices.at(name);
            for (auto const& id : validIds) {
                passedFilter = (id & frame) == id;
                if (passedFilter) {
                    break;
                }
            }
        }

        // Don't add if it didn't pass the filter
        if (!passedFilter) {
            continue;
        }

        if (id.canId == 0 && zeroSeen == false) {
            zeroSeen = true;
            
            if (numUnique > 0) {
                for (int k = 0; k < (int)numUnique; k++) {
                    CANScanIdentifier zeroId = id;
                    zeroId.uniqueId = *(idArray + counter++);
                    devices.insert({zeroId, true});
                }
            } else {
                devices.insert({id, true});
            }
        } else if (id.canId != 0) {
            devices.insert({id, true});
        }   
    }

    std::vector<CANScanIdentifier> identifiers;

    identifiers.reserve(devices.size());
    for (auto const& d : devices) {
        identifiers.push_back(d.first);
    }
    return identifiers;
}

void CANBusScanner::RegisterDevice(std::string name, std::vector<uint32_t> validIds) {
    if (validIds.size() > 0) {
        if (m_registeredDevices.find(name) == m_registeredDevices.end()) {
            // not found
            m_registeredDevices.insert(std::make_pair(name, validIds));
            m_lookUpMap.insert(std::make_pair(validIds[0] >> 16, name));
        } else {
            // is found, update valid ids
            std::vector<uint32_t> ids = m_registeredDevices.at(name);
            ids.insert(ids.end(), validIds.begin(), validIds.end());
            std::set<uint32_t> set;
            for (uint32_t& id : ids) {
                set.insert(id);
            }

            ids.assign(set.begin(), set.end());
            m_registeredDevices.at(name) = ids;
        }
    }
}
